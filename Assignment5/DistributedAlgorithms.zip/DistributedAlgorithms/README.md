# Distributed Algorithm Implementation

## Overview
A distributed system that demonstrates parallel computation by distributing number summation tasks across multiple nodes. The system implements a Leader-Client-Node architecture with consensus verification and performance comparison between sequential and distributed processing.

## Prerequisites
- Java 17 or higher
- Gradle 7.4.1 or higher
- Available ports:
  - 5000 (Leader)
  - 5001-5003 (Nodes)

## Building and Running
1. Build the project: gradle build
2. Start the Leader first: gradle runLeader
3. Start 3 nodes: gradle runNode1, runNode2, runNode3 (You may recieve error, but keep trying until it work)
4. Start the Client: gradle runClient
5. Run a faulty node: gradle runNode -Pfault=1

## Protocol Description
- The system implements a distributed sum calculation protocol:

1. The leader (Leader.java) partitions input numbers across nodes
2. Each Node processes its portion
3. The leader aggregates results and verifies consensus
4. The Client receives both sequential and distributed computation results

## Communication Flow
1. Client → Leader: List of numbers and delay parameter
2. Leader → Nodes: Distributed number partitions
3. Nodes → Leader: Partial sums
4. Leader → Client: Final sum and performance metrics

## Workflow Details
1. Client Operation
- Accepts comma-separated numbers and delay value
- Sends data to leader
- Displays results with timing comparison

2. Leader Operation
- Performs sequential calculation
- Distributes partitioned data to nodes
- Manages consensus verification
- Compares performance metrics

3. Node Operation
- Processes assigned number partitions
- Participates in consensus verification
- Can simulate faulty behavior for testing

## Requirements Fulfilled

- [x] Gradle project configuration
- [x] Leader-Client-Node architecture
- [x] Task distribution system
- [x] Parallel processing using threads
- [x] Consensus verification
- [x] Performance comparison
- [x] Fault simulation
- [x] Error handling

## Demonstration
link (https://somup.com/cZXtcbJ5tU)

## Performance Analysis

The distributed calculation provides performance benefits in scenarios with:
- Large input lists
- Significant processing delays
- Multiple available nodes

The system compares:
- Single-threaded sequential processing
- Multi-node distributed processing
- Performance metrics displayed in milliseconds

## Error Handling
The system handles:
- Insufficient connected nodes
- Node failures during processing
- Consensus failures
- Network communication errors
- Invalid input data
- Faulty node behavior